# PC3000-6E Troubleshooting AI Assistant (PWA)

Proyek awal untuk PWA Android + backend Cloudflare Worker + OpenAI Responses API.

## Isi paket
- `public/`: antarmuka PWA, form troubleshooting, riwayat lokal, service worker.
- `worker/`: backend API. API key disimpan sebagai secret di backend.
- Manual PDF belum dimasukkan ke paket; Anda harus mengunggah manual yang memang boleh Anda gunakan ke OpenAI File Search/vector store dan mengatur `VECTOR_STORE_ID`.

## Penting sebelum digunakan
1. Ini prototipe awal, bukan aplikasi produksi atau diagnosis resmi Komatsu.
2. Jangan memasukkan API key OpenAI ke `public/app.js`, HTML, GitHub, atau perangkat pengguna.
3. OpenAI API ditagih terpisah dari langganan ChatGPT. Atur billing/limit penggunaan sebelum pengujian.
4. Manual harus akurat dan sesuai varian/serial unit. Verifikasi jawaban dengan manual resmi dan prosedur site.
5. Backend contoh menggunakan CORS `*` untuk mempermudah uji awal. Sebelum dipakai tim/produksi, batasi origin ke domain PWA Anda dan tambahkan autentikasi/rate limit.
6. Riwayat di prototipe ini disimpan di localStorage browser perangkat. Hindari menyimpan data sensitif.

## Cara paling sederhana dari HP Android
Cara ini memerlukan akun layanan hosting. Semua langkah dilakukan melalui browser HP, tetapi mengedit file banyak lebih mudah bila memakai GitHub web editor.

### A. Publikasikan antarmuka PWA
1. Ekstrak ZIP.
2. Buat repository baru di GitHub, misalnya `pc3000-troubleshooting-ai`.
3. Unggah **isi folder `public`** ke root repository (index.html harus di root).
4. Buka Settings > Pages. Pilih deploy dari branch `main`, folder `/ (root)`, lalu Save.
5. Tunggu URL Pages muncul. PWA membutuhkan HTTPS.
6. Buka URL itu di Chrome Android. Menu ⋮ > **Tambahkan ke layar utama** / **Install app**.
7. Untuk awal, aplikasi akan tampil tetapi AI belum tersambung sampai backend dipublikasikan.

### B. Siapkan backend Cloudflare Worker
1. Buat akun Cloudflare dan buka Workers & Pages.
2. Buat Worker baru.
3. Buka editor kode Worker, ganti kode contoh dengan isi `worker/index.js`, lalu deploy.
4. Di pengaturan Worker, tambahkan secret `OPENAI_API_KEY` (jangan menaruhnya di kode).
5. Tambahkan variable `OPENAI_MODEL` sesuai model yang tersedia untuk akun API Anda, misalnya `gpt-4.1-mini`.
6. (Opsional, untuk pencarian manual) tambahkan variable `VECTOR_STORE_ID` setelah membuat vector store dan mengunggah PDF manual ke OpenAI File Search.
7. Salin URL Worker, misalnya `https://nama-worker.<akun>.workers.dev`.

### C. Sambungkan PWA ke backend
1. Buka `public/app.js` di repository GitHub.
2. Ganti baris `const API_BASE = "";` menjadi URL Worker Anda, tanpa garis miring di akhir.
3. Simpan/commit perubahan.
4. Tunggu GitHub Pages selesai memperbarui situs, lalu muat ulang PWA.
5. Uji dengan gejala contoh yang tidak berbahaya. Pastikan status menunjukkan analisis selesai.

### D. Hubungkan manual PDF
1. Di OpenAI Platform, siapkan vector store untuk File Search.
2. Unggah manual PDF PC3000-6E yang Anda miliki dan memang boleh diproses secara online.
3. Salin ID vector store dan simpan sebagai variable `VECTOR_STORE_ID` pada Worker.
4. Uji pertanyaan dengan istilah yang ada di manual. AI harus menyebutkan jika referensi tidak ditemukan; tetap cocokkan jawaban dengan PDF asli.

## Troubleshooting
- `OPENAI_API_KEY belum diatur`: buat secret di pengaturan Worker.
- `401/invalid API key`: periksa key dan status proyek API.
- `429` / quota / billing: periksa limit dan billing OpenAI API.
- `Failed to fetch`: periksa URL `API_BASE`, deployment Worker, dan CORS.
- Manual belum aktif: pastikan `VECTOR_STORE_ID` benar dan vector store berisi file.
- Aplikasi tidak bisa dipasang: pastikan situs memakai HTTPS dan buka melalui Chrome Android.

## Catatan keamanan untuk penggunaan lapangan
Jangan memakai AI untuk menggantikan LOTOTO, pengukuran oleh teknisi kompeten, atau prosedur resmi. Jangan bypass interlock. Jangan membuka fitting hidrolik saat bertekanan. Jangan memasukkan informasi perusahaan yang bersifat rahasia tanpa izin.
